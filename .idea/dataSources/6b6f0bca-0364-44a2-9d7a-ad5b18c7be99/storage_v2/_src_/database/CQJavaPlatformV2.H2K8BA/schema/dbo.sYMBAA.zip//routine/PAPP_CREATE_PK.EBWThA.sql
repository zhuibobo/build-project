
CREATE PROCEDURE PAPP_CREATE_PK(@p_tableID VARCHAR (100),
	@p_tableName VARCHAR (100))
AS
DECLARE
	@v_pkfields VARCHAR (255);

DECLARE
	@v_pkfield VARCHAR (255);

DECLARE
	@v_fieldsLen INT;

DECLARE
	@v_sql VARCHAR (255);

DECLARE
	@done INT = - 1;

DECLARE
	fieldCursor CURSOR FOR SELECT
		FIELD_NAME
	FROM
		TAPP_FIELD
	WHERE
		TABLE_ID = @p_tableID
	AND IS_PK = 1;

BEGIN
SET @done = 1;


SET @v_pkfields = ' ';

OPEN fieldCursor;

FETCH NEXT FROM fieldCursor INTO @v_pkfield

WHILE @@FETCH_STATUS =0
BEGIN 
	IF @done = 1 
		begin
			break;
		end
	ELSE
		begin
			IF CHARINDEX(@v_pkfields, @v_pkfield) < 1
				begin
					SET @v_pkfields = @v_pkfields + @v_pkfield  + ',';
				end
		end

	
	FETCH NEXT FROM fieldCursor INTO @v_pkfield
	
END 

CLOSE fieldCursor 
DEALLOCATE fieldCursor 


IF @v_pkfields <> ' '
	begin
		SET @v_pkfields = LTRIM(@v_pkfields);
	end



IF @v_pkfields <> ' ' AND @v_pkfields <> ','
	begin
		SET @v_fieldsLen = LEN(@v_pkfields);
		SET @v_pkfields = substring(@v_pkfields, 1, @v_fieldsLen-1);

		SET @v_sql = 'ALTER TABLE '  + @p_tableName + ' ADD ' + @v_pkfields + ' int not null ' + ' PRIMARY KEY';

		
		EXEC(@v_sql);
	end
end

GO

