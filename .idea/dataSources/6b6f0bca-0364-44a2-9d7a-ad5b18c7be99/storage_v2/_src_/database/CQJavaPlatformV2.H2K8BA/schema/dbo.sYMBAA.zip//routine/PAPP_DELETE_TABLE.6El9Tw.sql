
CREATE PROCEDURE PAPP_DELETE_TABLE(@tableName VARCHAR(30))
AS

DECLARE @v_sql varchar(255);

DECLARE @v_count INT;
BEGIN

select
	@v_count = COUNT(*) 
from
	sysobjects
where
	id = object_id(@tableName) and type = 'U'

IF @v_count > 0
	begin
		SET @v_sql = 'DROP TABLE ' + @tableName;

		EXEC(@v_sql);
	end
END

GO

