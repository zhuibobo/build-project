CREATE VIEW VAPP_TABLEEXISTED AS select name as TABLE_NAME from sysobjects where type = 'U';
GO

