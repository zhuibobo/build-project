
CREATE PROCEDURE PAPP_DELETE_FIELD(@p_tableID VARCHAR (100),
	@p_tableName VARCHAR (100),
	@p_fieldID BIGINT)
AS
DECLARE
	@v_sql VARCHAR (255);

DECLARE
	@v_fieldName VARCHAR (50);

DECLARE
	@v_count INT;
BEGIN
SELECT
	@v_fieldName = FIELD_NAME 
FROM
	TAPP_FIELD
WHERE
	TABLE_ID = @p_tableID
AND FIELD_ID = @p_fieldID;

select 
	@v_count = COUNT(*) 
from 
	syscolumns
where 
	id=object_id(@p_tableName) 
	and UPPER(name)=UPPER(@v_fieldName);


IF @v_count > 0 
	begin
		set @v_sql = 'ALTER TABLE ' + @p_tableName + ' DROP COLUMN ' + @v_fieldName + '';

		EXEC(@v_sql);
	end



END

GO

