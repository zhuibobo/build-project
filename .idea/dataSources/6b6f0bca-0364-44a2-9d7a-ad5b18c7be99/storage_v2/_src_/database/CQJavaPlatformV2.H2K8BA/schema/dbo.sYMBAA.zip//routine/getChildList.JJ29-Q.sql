
CREATE FUNCTION getChildList(@CATEID varchar(100)) RETURNS varchar(1000)
AS
BEGIN

DECLARE @pTemp VARCHAR (1000);

with cte
as 
(
select CATEGORY_ID, PARENT_ID from TAPP_CATEGORY
where CATEGORY_ID = @CATEID 
union all 
select t.CATEGORY_ID, t.PARENT_ID from TAPP_CATEGORY as t 
inner join cte as c on t.PARENT_ID = c.CATEGORY_ID 
where MY_TYPE = 2
)

select @pTemp = (stuff((select N','+ CATEGORY_ID 
	from cte 
	FOR XML PATH('')), 1, 1, N'')
  )
from cte

return @pTemp;

END

GO

