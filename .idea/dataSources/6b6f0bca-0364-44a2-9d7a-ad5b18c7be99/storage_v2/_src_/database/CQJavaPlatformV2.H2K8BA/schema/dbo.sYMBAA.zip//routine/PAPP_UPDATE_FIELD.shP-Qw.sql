
CREATE PROCEDURE PAPP_UPDATE_FIELD(@p_tableID  varchar(100),
	@p_tableName  varchar(100),
	@p_fieldID  bigint)
AS 
	DECLARE @v_sql varchar (255);

	DECLARE @v_fieldName varchar(100);

	DECLARE @v_dataType  bigint;

	DECLARE @v_dataLength  bigint;

	DECLARE @v_decimalLength  bigint;

	DECLARE @v_allowNull  bigint;

	DECLARE @v_isUnique  bigint;

	DECLARE @v_isPK  bigint;

	DECLARE @v_orignalFieldAllowNull varchar (10);

	DECLARE @v_oracleVersion varchar(100);
BEGIN
	SELECT
		@v_fieldName = FIELD_NAME,
		@v_dataType = DATA_TYPE,
		@v_dataLength = DATA_LENGTH,
		@v_decimalLength = DECIMAL_LENGTH,
		@v_allowNull = ALLOW_NULL,
		@v_isUnique = IS_UNIQUE,
		@v_isPK = IS_PK 
	FROM
		TAPP_FIELD
	WHERE
		TABLE_ID = @p_tableID
	AND FIELD_ID = @p_fieldID;
	
	IF @v_fieldName = 'ID'
		begin
    	return;
  	end

   /**转义**/
	SET @v_sql = ' ' + @v_fieldName + ' ';


	if @v_dataType = 1 
		begin
			set @v_sql = @v_sql + ' bigint ';
		end
	else if @v_dataType = 2
		begin
			set @v_sql = @v_sql + ' numeric';
		end
	else if @v_dataType = 3
		begin
			set @v_sql = @v_sql + ' DATETIME ';
		end
	else if @v_dataType = 4
		begin
			set @v_sql = @v_sql + ' varchar ';
		end
	else if @v_dataType = 5
		begin
			set @v_sql = @v_sql + ' tinyint ';  
		end
	else if @v_dataType = 6
		begin
			set @v_sql = @v_sql + ' TEXT ';
		end
	else if @v_dataType = 7
		begin
			set @v_sql = @v_sql + ' DATE';
		end
	else if @v_dataType = 8
		begin
			set @v_sql = @v_sql + ' TEXT';
		end

IF (@v_dataType = 4 OR @v_dataType = 3 OR @v_dataType = 7)
	begin
		IF (@v_dataLength > 0)
			begin
				SET @v_sql = @v_sql + '(' + cast(@v_dataLength as varchar) + ')';
			end
		ELSE
			begin
				SET @v_sql = @v_sql + '(50)';
			end
	end

/**处理小数**/
IF (@v_dataType = 2)
	begin
		IF (@v_dataLength > 0 AND @v_decimalLength > 0)
			begin
				SET @v_sql = @v_sql + '(' + cast(@v_dataLength as varchar) + ',' + cast(@v_decimalLength as varchar) + ')';
			end
		ELSE IF ( @v_dataLength > 0 AND @v_decimalLength <= 0 )
			begin
				SET @v_sql = @v_sql + '(' + cast(@v_dataLength as varchar) + ')';
			end
	end


/**处理是否为空**/
IF (@v_allowNull = 0)
	begin
		SET @v_sql = @v_sql + ' NOT NULL ';
	end

IF (@v_allowNull <> 0 )
	begin
		SET @v_sql = @v_sql + ' NULL ';
	end


/**拼接SQL**/
SET @v_sql = 'ALTER TABLE ' + @p_tableName + ' ALTER COLUMN ' + @v_sql + '';

EXEC(@v_sql);

END

GO

