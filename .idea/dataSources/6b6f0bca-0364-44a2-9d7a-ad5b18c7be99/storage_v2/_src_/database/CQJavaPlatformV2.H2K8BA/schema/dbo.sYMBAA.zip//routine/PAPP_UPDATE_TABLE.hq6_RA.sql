
CREATE PROCEDURE PAPP_UPDATE_TABLE(@tableID  VARCHAR(100),
	@deleteFieldID  VARCHAR(255),
	@updateFieldID  VARCHAR(255),
	@addNewFieldID  VARCHAR(255),
	@isPKChanged INT)
AS
 DECLARE @p_tableID VARCHAR (100);

 DECLARE @p_deleteFieldID VARCHAR (255);

 DECLARE @p_updateFieldID VARCHAR (255);

 DECLARE @p_addNewFieldID VARCHAR (255);

 DECLARE @p_isPKChanged INT;

 DECLARE @v_deleteFieldID VARCHAR (255);

 DECLARE @v_updateFieldID VARCHAR (255);

 DECLARE @v_addNewFieldID VARCHAR (255);

 DECLARE @v_tableName VARCHAR(100);

 DECLARE @v_fieldID VARCHAR (255);

 DECLARE @v_len INT;

 DECLARE @v_loop INT;

 DECLARE @v_pkNum INT;

 DECLARE @v_sql VARCHAR (255);
BEGIN
	SET @p_tableID = @tableID;

	SET @p_deleteFieldID = @deleteFieldID;

	SET @p_updateFieldID = @updateFieldID;

	SET @p_addNewFieldID = @addNewFieldID;

	SET @p_isPKChanged = @isPKChanged;

SELECT
	@v_tableName = TABLE_NAME 
FROM
	TAPP_TABLE
WHERE
	TABLE_ID = @p_tableID;

	SET @v_deleteFieldID = LTRIM(@p_deleteFieldID);

	SET @v_deleteFieldID = RTRIM(@v_deleteFieldID);

	SET @v_len = LEN(@v_deleteFieldID);

	SET @v_loop = 1;

	SET @v_fieldID = '';

WHILE @v_loop <= @v_len
	begin
		/**执行删除操作**/
		IF SUBSTRING(@v_deleteFieldID, @v_loop, 1) = ','
			begin
				EXEC PAPP_DELETE_FIELD @p_tableID, @v_tableName, @v_fieldID;
				SET @v_fieldID = '';
			end
		ELSE
			begin
				SET @v_fieldID = @v_fieldID + SUBSTRING(@v_deleteFieldID, @v_loop, 1);
			end


		IF @v_loop = @v_len AND @v_loop <> 0
			begin
				EXEC PAPP_DELETE_FIELD @p_tableID, @v_tableName, @v_fieldID;
			end
		SET @v_loop = @v_loop + 1;
	end


/**处理更新**/
SET @v_updateFieldID = LTRIM(@p_updateFieldID);

SET @v_updateFieldID = RTRIM(@v_updateFieldID);

SET @v_len = LEN(@v_updateFieldID);

SET @v_loop = 1;

SET @v_fieldID = '';

WHILE @v_loop <= @v_len
	begin

		IF SUBSTRING(@v_updateFieldID, @v_loop, 1) = ','
			begin
				EXEC PAPP_UPDATE_FIELD @p_tableID, @v_tableName, @v_fieldID;
				SET @v_fieldID = '';
			end
		ELSE
			begin
				SET @v_fieldID = @v_fieldID + SUBSTRING(@v_updateFieldID, @v_loop, 1);
			end


		IF @v_loop = @v_len AND @v_loop <> 0
			begin
				EXEC PAPP_UPDATE_FIELD @p_tableID, @v_tableName, @v_fieldID;
			end
		
		SET @v_loop = @v_loop + 1;
	end


/**处理新增**/
SET @v_addNewFieldID = LTRIM(@p_addNewFieldID);

SET @v_addNewFieldID = RTRIM(@v_addNewFieldID);

SET @v_len = LEN(@v_addNewFieldID);

SET @v_loop = 1;

SET @v_fieldID = '';

WHILE @v_loop <= @v_len
	begin
		IF SUBSTRING(@v_addNewFieldID, @v_loop, 1) = ','
			begin
				EXEC PAPP_ADDNEW_FIELD @p_tableID, @v_tableName, @v_fieldID;
				SET @v_fieldID = '';
			end
		ELSE
			begin
				SET @v_fieldID = @v_fieldID + SUBSTRING(@v_addNewFieldID, @v_loop, 1);
			end


		IF @v_loop = @v_len AND @v_loop <> 0
			begin
				EXEC PAPP_ADDNEW_FIELD @p_tableID, @v_tableName, @v_fieldID;
			end
		
		SET @v_loop = @v_loop + 1;
	end



IF @p_isPKChanged = 1
	begin
		SET @v_pkNum = 0;
		SELECT
			@v_pkNum = COUNT(*) 
		FROM
			user_constraints
		WHERE
			table_name = upper(@v_tableName)
		AND constraint_type = 'P';

		IF @v_pkNum = 1
			begin
				SET @v_sql = 'ALTER TABLE ' + @v_tableName + ' DROP PRIMARY KEY';
				EXEC(@v_sql);
			end

		EXEC PAPP_CREATE_PK @p_tableID, @v_tableName;
	
	end
END

GO

