
CREATE PROCEDURE PAPP_ADDNEW_TABLE(@tableID  VARCHAR(200),
	@fieldIDS  VARCHAR(200))
AS
	DECLARE @p_tableID VARCHAR(200);
	
	DECLARE @p_fieldIDS VARCHAR (200);

	DECLARE @v_tableName VARCHAR(200);

	DECLARE @v_fieldID varchar (200);

	DECLARE @v_sql VARCHAR (500);

	DECLARE @v_len INT;

	DECLARE @v_loop INT;
BEGIN
	set @p_tableID = @tableID;

	set @p_fieldIDS = @fieldIDS;

SELECT
	@v_tableName = TABLE_NAME 
FROM
	TAPP_TABLE
WHERE
	TABLE_ID = @p_tableID;

set @v_sql = 'CREATE TABLE ' + @v_tableName + ' (ID VARCHAR(50) NOT NULL PRIMARY KEY)';

EXEC(@v_sql);

set @v_fieldID = '';

set @v_len = LEN(@p_fieldIDS);

set @v_loop = 1;


WHILE @v_loop <= @v_len 
	begin
		IF substring(@p_fieldIDS, @v_loop, 1) = ','
			begin
				EXEC PAPP_ADDNEW_FIELD @p_tableID,@v_tableName,@v_fieldID 
				set @v_fieldID = '';
			end

		ELSE
			begin

				set @v_fieldID = @v_fieldID + substring(@p_fieldIDS, @v_loop, 1);
			end
		

		IF @v_loop = @v_len
			begin
				EXEC PAPP_ADDNEW_FIELD @p_tableID,@v_tableName,@v_fieldID 
			end

		set @v_loop = @v_loop + 1;

	end
end

GO

