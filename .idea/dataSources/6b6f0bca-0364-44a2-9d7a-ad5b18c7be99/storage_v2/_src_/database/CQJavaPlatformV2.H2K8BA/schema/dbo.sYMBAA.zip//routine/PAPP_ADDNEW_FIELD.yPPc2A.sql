
CREATE PROCEDURE PAPP_ADDNEW_FIELD @p_tableID VARCHAR (100),
	@p_tableName VARCHAR (100),
	@p_fieldID BIGINT 
AS
DECLARE
	@v_sql VARCHAR (255);

DECLARE
	@v_fieldName VARCHAR (100);

DECLARE
	@v_dataType BIGINT;

DECLARE
	@v_dataLength BIGINT;

DECLARE
	@v_decimalLength BIGINT;

DECLARE
	@v_allowNull BIGINT;

DECLARE
	@v_isUnique BIGINT;

DECLARE
	@v_isPK BIGINT;
BEGIN
SELECT
	@v_fieldName = FIELD_NAME,
	@v_dataType = DATA_TYPE,
	@v_dataLength = DATA_LENGTH,
	@v_decimalLength = DECIMAL_LENGTH,
	@v_allowNull = ALLOW_NULL,
	@v_isUnique = IS_UNIQUE,
	@v_isPK = IS_PK 
	
FROM
	TAPP_FIELD
WHERE
	table_id = @p_tableID
AND FIELD_ID = @p_fieldID;

/**转义**/
set @v_sql = ' ' + @v_fieldName + ' ';

if @v_dataType = 1 
	begin
		set @v_sql = @v_sql + ' bigint ';
	end
else if @v_dataType = 2
	begin
		set @v_sql = @v_sql + ' numeric';
	end
else if @v_dataType = 3
	begin
		set @v_sql = @v_sql + ' DATETIME ';
	end
else if @v_dataType = 4
	begin
		set @v_sql = @v_sql + ' varchar ';
	end
else if @v_dataType = 5
	begin
		set @v_sql = @v_sql + ' tinyint ';  
	end
else if @v_dataType = 6
	begin
		set @v_sql = @v_sql + ' TEXT ';
	end
else if @v_dataType = 7
	begin
		set @v_sql = @v_sql + ' DATE';
	end
else if @v_dataType = 8
	begin
		set @v_sql = @v_sql + ' TEXT';
	end


IF (@v_dataType = 4)
	BEGIN
		IF (@v_dataLength > 0)
			BEGIN
				set @v_sql = @v_sql + '(' + cast(@v_dataLength as varchar) + ')';
			END
		ELSE
			BEGIN
				set @v_sql = @v_sql + '(100)';
		END
	END


IF (@v_dataType = 2) 
	begin
		IF (@v_dataLength > 0 AND @v_decimalLength > 0 )
			begin
				SET @v_sql = @v_sql + '(' + cast(@v_dataLength as varchar) + ',' + cast(@v_decimalLength as varchar) + ')';
			end
		ELSE IF @v_dataLength > 0 AND @v_decimalLength <= 0
			begin
				SET @v_sql = @v_sql + '(' + cast(@v_dataLength as varchar) + ')';
			end

		
	end


IF (@v_allowNull = 0 AND @v_dataType <> 6)
	BEGIN
		SET @v_sql = @v_sql + ' NOT NULL ';
	END


SET @v_sql = 'alter table ' + @p_tableName + ' add ' + @v_sql;

EXEC(@v_sql);

end

GO

